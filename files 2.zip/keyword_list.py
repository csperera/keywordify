"""
Generate a 3-column keyword list in order of appearance.
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from typing import List
import math


class KeywordListGenerator:
    """Generate a 3-column keyword list PDF."""
    
    PAGE_WIDTH, PAGE_HEIGHT = letter
    MARGIN = 0.75 * inch
    COLUMN_GAP = 0.5 * inch
    
    def __init__(self, output_path: str):
        """Initialize keyword list generator."""
        self.output_path = output_path
    
    def generate(self, keywords: List[str]):
        """
        Generate 3-column keyword list.
        
        Args:
            keywords: List of keywords in order of appearance
        """
        c = canvas.Canvas(self.output_path, pagesize=letter)
        
        # Calculate column widths
        total_content_width = self.PAGE_WIDTH - (2 * self.MARGIN)
        column_width = (total_content_width - (2 * self.COLUMN_GAP)) / 3
        
        # Column X positions
        col1_x = self.MARGIN
        col2_x = self.MARGIN + column_width + self.COLUMN_GAP
        col3_x = self.MARGIN + (2 * column_width) + (2 * self.COLUMN_GAP)
        
        # Calculate rows per column
        rows_per_column = math.ceil(len(keywords) / 3)
        
        # Title
        c.setFont("Helvetica-Bold", 14)
        c.drawString(self.MARGIN, self.PAGE_HEIGHT - self.MARGIN, "Keywords (in order of appearance)")
        
        # Starting Y position for keywords
        y_start = self.PAGE_HEIGHT - self.MARGIN - 0.5 * inch
        line_height = 0.25 * inch
        
        c.setFont("Helvetica", 11)
        
        # Fill columns top-to-bottom, left-to-right
        for idx, keyword in enumerate(keywords):
            column = idx // rows_per_column
            row = idx % rows_per_column
            
            if column == 0:
                x = col1_x
            elif column == 1:
                x = col2_x
            else:
                x = col3_x
            
            y = y_start - (row * line_height)
            
            # Draw keyword with bullet
            c.drawString(x, y, f"• {keyword}")
        
        c.save()
        print(f"Keyword list generated: {self.output_path}")
